//
//  YYClient.m
//  BonjourDemo
//
//  Created by 张树青 on 2017/3/22.
//  Copyright © 2017年 zsq. All rights reserved.
//

#import "YYClient.h"
#import "ServerBrowser.h"
#import "ServerBrowserDelegate.h"
#import "Connection.h"

@interface YYClient() <ServerBrowserDelegate, ConnectionDelegate>
@property (nonatomic, strong) ServerBrowser* serverBrowser;
@property (nonatomic, strong) Connection *connection;
@property (nonatomic, strong) NSThread *thread;
@property (nonatomic, copy) NSString *serverName;
@end

@implementation YYClient

- (void)strtWithServerName:(NSString *)serverName{
    
    if (self.serverBrowser) {
        [self stop];
        self.serverBrowser = nil;
    }
    self.serverName = serverName;
    
    self.thread = [[NSThread alloc]initWithTarget:self selector:@selector(run) object:nil];
    [self.thread start];
    
    [self performSelector:@selector(action) onThread:self.thread withObject:nil waitUntilDone:NO ];

}
- (void)action{
    self.serverBrowser = [[ServerBrowser alloc] init];
    self.serverBrowser.delegate = self;
    self.serverBrowser.serverName = self.serverName;
    [self.serverBrowser start];
}
- (void)run{
    //只要往RunLoop中添加了  timer、source或者observer就会继续执行，一个Run Loop通常必须包含一个输入源或者定时器来监听事件，如果一个都没有，Run Loop启动后立即退出。
    
    @autoreleasepool {
        
        //1、添加一个input source
        [[NSRunLoop currentRunLoop] addPort:[NSPort port] forMode:NSDefaultRunLoopMode];
        [[NSRunLoop currentRunLoop] run];
        //        //2、添加一个定时器
        //            NSTimer *timer = [NSTimer timerWithTimeInterval:0.001 target:self selector:@selector(test) userInfo:nil repeats:YES];
        //            [[NSRunLoop currentRunLoop] addTimer:timer forMode:NSDefaultRunLoopMode];
        //            [[NSRunLoop currentRunLoop] run];
    }
}
- (void)test{
    
}

- (void)stop{
    [self.serverBrowser stop];
    if ( self.connection == nil ) {
        return;
    }
    [self.connection close];
    self.connection = nil;
}

#pragma mark - ServerBrowser delegate
- (void)updateServerList {
    //[serverList reloadData];
}
- (void)findWantServer:(NSNetService *)netService{
    //找到服务, 停止扫描
    NSLog(@"发现server: %@", netService.name);
    [self stop];
    self.connection = [[Connection alloc] initWithNetService:netService];
    if (self.connection == nil) {
        return;
    }
    
    self.connection.delegate = self;
    [self.connection connect];
}


#pragma mark - connection delegate
- (void)connectionAttemptFailed:(Connection*)connection {
    NSLog(@"连接服务失败, 重新开始扫描");
    [self.serverBrowser start];
}
- (void)connectionTerminated:(Connection*)connection {
    NSLog(@"连接中断, 重新开始扫描服务");
    [self.serverBrowser start];
}
- (void)receivedNetworkPacket:(NSString *)packet viaConnection:(Connection*)connection {
    if (packet && [packet isKindOfClass:[NSString class]] && ((NSString *)packet).length>0) {
        NSLog(@"client收到消息:%@", packet);
        NSNumber *str = @([[NSDate date] timeIntervalSince1970]);
        [self.connection sendNetworkPacket:str];
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(client:receiveMessage:)]) {
            [self.delegate client:self receiveMessage:packet];
        }
    }

}

@end
