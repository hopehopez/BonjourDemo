//
//  YYServer.h
//  BonjourDemo
//
//  Created by 张树青 on 2017/3/22.
//  Copyright © 2017年 zsq. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol YYServerDelegate <NSObject>


@end

@interface YYServer : NSObject

+ (instancetype)shareInsatance;

- (void)startServerWithName:(NSString *)name;
- (void)stopServer;

- (void)sendMessage:(NSString *)message;

@property (nonatomic, weak) id<YYServerDelegate> delegate;

@end
